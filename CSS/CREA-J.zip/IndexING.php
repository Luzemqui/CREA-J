<?php
session_start();
//Verificar si la sesion esta iniciada
if (isset($_SESSION["userSession"])) {
    $isEnglish   = strpos($_SERVER["REQUEST_URI"], "/INGLES/") !== false;
    $redirectUrl = $isEnglish ? "../HTML/INGLES/PrincipalING.php" : "../HTML/ESPANOL/Principal.php";
    
    header("Location: " . $redirectUrl);
    exit; 
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canrisk - Cancer information and support</title>
    <link rel="stylesheet" href="CSS/Style-Info.css">
    <link rel="stylesheet" href="CSS/principal.css">
    <link rel="stylesheet" href="CSS/cancer.css">
    <link rel="icon" type="image/png" href="MULTIMEDIA/Canrisk LOGO.svg">
</head>
<body>

    <!-- LOGO AND SIDEBAR TOGGLE BUTTON -->
    <div class="navbar-brand">
        <button class="hamburger-sidebar-btn" id="sidebarBtn" aria-label="Open side menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <h1>Canrisk</h1>
        <img src="MULTIMEDIA/Canrisk LOGO.svg" alt="Canrisk" class="C-L">
    </div>

    <!-- SIDE MENU -->
    <nav class="sidebar-menu" id="sidebarMenu">
        <div class="sidebar-decoracion">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <ul class="sidebar-list">
            <li><a href="IndexING.php">Home &rarr;</a></li>
            <li><a href="Recetas.N.php">Healthy Recipes &rarr;</a></li>
        </ul>
    </nav>

    <!-- DARK OVERLAY WHEN SIDEBAR IS OPEN -->
    <div class="overlay-menu" id="menuOverlay"></div>

    <!-- TOP NAVIGATION BAR -->
    <nav class="navbar" id="mainNav">


        <ul class="Info-nav">
            <li class="box-II"><h4><a href="Faq.N-ING.php">Frequently Asked Questions</a></h4></li>
            <li class="box-II"><a href="IndexING.php"><h4>Home Page</h4></a></li>
        </ul>

        <div class="right-group">
            <ul class="Index">
                <li class="box-I"><a href="HTML/INGLES/loginING.php"><h4>Log in</h4></a></li>
                <li class="box-I"><a href="HTML/INGLES/registerING.php"><h4>Sign Up</h4></a></li>
            </ul>
            <a id="langSwitchNL" class="lang-switchNL" href="index.php" aria-label="Cambiar idioma / Switch language">ES</a>
            <div class="Photo">
                <img src="MULTIMEDIA/profile.png" class="PP-default" alt="User profile picture">
            </div>
        </div>

    </nav>
    <!-- ENCABEZADO PRINCIPAL (HERO) --> 
    <header class="hero-section">
    <!-- CAROUSEL DE IMAGENES -->
    <div class="carousel">
        <div class="carousel-track" id="track">
        <div class="carousel-slide"><img src="MULTIMEDIA/1.jpg" alt="Canrisk - image 1"></div>
        <div class="carousel-slide"><img src="MULTIMEDIA/5.jpg" alt="Canrisk - image 2"></div>
        <div class="carousel-slide"><img src="MULTIMEDIA/6.jpg" alt="Canrisk - image 3"></div>
        </div>
        <div class="carousel-container">
            <button class="carousel-button prev" onclick="prevSlide()">❮</button>
            <button class="carousel-button next" onclick="nextSlide()">❯</button>

            <!-- NUEVO: Contenedor de indicadores de línea (abajo del carrusel) -->
            <div class="carousel-indicators-lines">
                <!-- Agrega un botón por cada imagen/slide que tengas en tu carrusel -->
                <button class="indicator-line active" onclick="currentSlide(0)"></button>
                <button class="indicator-line" onclick="currentSlide(1)"></button>
                <button class="indicator-line" onclick="currentSlide(2)"></button>
            </div>
        </div>
    </div>
        <br>
        <div class="hero-container">
            <div class="Titulos-DEG">
                <h1 class="hero-title">Canrisk, your information site about cancer</h1>
            </div>
            <p class="hero-subtitle">
                Prevention tools, emotional support, and accompaniment for young people and families
                facing cancer treatment.
                <br>
                <strong>
                    <span class="Negrita">This platform does NOT replace professional medical help.</span>
                </strong>
            </p>
        </div>
             
</div>
<br>
</div>
    </div>
        <div class="action-container" style="padding-top: 0;">
                <a href="HTML/ESPANOL/register.php" class="btn-quizz">Register today and be part of the change</a>
    </div>
    </header>


    <!-- "WHAT'S OUR GOAL?" SECTION -->
    <section class="info-row-container">
        <br>
        <h2 class="info-row-title">What's Our Goal?</h2>
        <div class="info-grid">
            <div class="info-card">
                <h3>Awareness</h3>
                <p>We share information about the different types of cancer and how to support a
                    family member going through the disease.</p>
            </div>
            <div class="info-card">
                <h3>Real Support</h3>
                <p>We offer financial and psychological guidance to those who don't have many
                    resources to cover their treatments.</p>
            </div>
            <div class="info-card">
                <h3>Privacy First</h3>
                <p>We respect the privacy of every person who seeks help on our site, without
                    exception.</p>
            </div>
        </div>
    </section>

    <script>
        /* Sidebar (only exists on internal pages) */
        const sidebarBtn = document.getElementById('sidebarBtn');
        const sidebarMenu = document.getElementById('sidebarMenu');
        const menuOverlay = document.getElementById('menuOverlay');

        if (sidebarBtn && sidebarMenu && menuOverlay) {
            const toggleSidebar = () => {
                const isOpen = sidebarMenu.classList.toggle('open');
                sidebarBtn.classList.toggle('open', isOpen);
                menuOverlay.classList.toggle('show', isOpen);
                sidebarBtn.setAttribute('aria-expanded', isOpen);
            };
            sidebarBtn.addEventListener('click', toggleSidebar);
            menuOverlay.addEventListener('click', toggleSidebar);
        }

        /* ---- Carousel ---- */
        var LIGHT_CAROUSEL_IMAGES = ['MULTIMEDIA/1.jpg', 'MULTIMEDIA/5.jpg', 'MULTIMEDIA/6.jpg'];
        var DARK_CAROUSEL_IMAGES = ['MULTIMEDIA/9.jpg', 'MULTIMEDIA/13.jpg', 'MULTIMEDIA/14.jpg', 'MULTIMEDIA/15.jpg'];

        var currentSlideIndex = 0;
        var track = document.getElementById('track');
        var indicatorsWrap = document.querySelector('.carousel-indicators-lines');
        var carousel = document.querySelector('.carousel');
        var slides = document.querySelectorAll('.carousel-slide');
        var indicators = document.querySelectorAll('.indicator-line');

        function showSlide(index) {
            if (!track || slides.length === 0) return;
            // Wrap around
            if (index >= slides.length) index = 0;
            if (index < 0) index = slides.length - 1;
            currentSlideIndex = index;

            // Move the track
            track.style.transform = 'translateX(-' + (currentSlideIndex * 100) + '%)';

            // Update indicator lines
            indicators.forEach(function(ind) { ind.classList.remove('active'); });
            if (indicators[currentSlideIndex]) {
                indicators[currentSlideIndex].classList.add('active');
            }
        }

        function nextSlide() { showSlide(currentSlideIndex + 1); }
        function prevSlide() { showSlide(currentSlideIndex - 1); }
        function currentSlide(index) { showSlide(index); }

        // Rebuilds the carousel with the active theme's image set.
        function buildCarousel(images) {
            if (!track || !indicatorsWrap) return;
            track.innerHTML = '';
            indicatorsWrap.innerHTML = '';
            images.forEach(function (src, i) {
                var slide = document.createElement('div');
                slide.className = 'carousel-slide';
                var img = document.createElement('img');
                img.src = src;
                img.alt = 'Canrisk - image ' + (i + 1);
                slide.appendChild(img);
                track.appendChild(slide);

                var dot = document.createElement('button');
                dot.className = 'indicator-line' + (i === 0 ? ' active' : '');
                dot.setAttribute('onclick', 'currentSlide(' + i + ')');
                indicatorsWrap.appendChild(dot);
            });
            slides = document.querySelectorAll('.carousel-slide');
            indicators = document.querySelectorAll('.indicator-line');
            currentSlideIndex = 0;
            showSlide(0);
        }

        function applyCarouselTheme(theme) {
            buildCarousel(theme === 'dark' ? DARK_CAROUSEL_IMAGES : LIGHT_CAROUSEL_IMAGES);
        }

        // The HTML already ships the light set by default; only rebuild when
        // the active theme is dark, to avoid repainting the carousel for nothing.
        if (document.documentElement.getAttribute('data-theme') === 'dark') {
            applyCarouselTheme('dark');
        }
        document.addEventListener('canrisk:theme-change', function (e) {
            applyCarouselTheme(e.detail && e.detail.theme);
        });

        // Auto-play: avanza cada 15 s, se pausa al pasar el cursor
        var autoPlay = setInterval(nextSlide, 15000);
        if (carousel) {
            carousel.addEventListener('mouseenter', function() { clearInterval(autoPlay); });
            carousel.addEventListener('mouseleave', function() {
                autoPlay = setInterval(nextSlide, 15000);
            });
        }
    </script>
    <script src="JS/site.js" defer></script>

    <!-- FOOTER -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-col">
                    <h2 class="Title">COPYRIGHT</h2>
                    <ul class="Advice">
                        <li>&copy; Canrisk 2026</li>
                        <li>All rights reserved to the Canrisk team.</li>
                        <li>Special thanks to the whole team who made this page possible.</li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h2 class="Title_1">IMPORTANT INFORMATION</h2>
                    <ul class="Advice_1">
                        <li>This page DOES NOT replace the help of a medical professional.</li>
                        <li>In case of an emergency or symptom, rely on the hospital numbers
                            that we provide, or call 911 directly.</li>
                    </ul>
                </div>
            </div>
        <div class="footer-social">
            <h2 class="Title_2">Canrisk's social media!</h2>
            <ul class="Social">
                <li><a href="https://www.instagram.com/canrisk/" target="_blank"><img src="MULTIMEDIA/instagram.png" class="Inst-IMG" alt="Instagram logo"><p class="Inst-txt">Instagram</p></a></li>
                <li><a href="https://www.facebook.com/Canrisk-110882646091155" target="_blank"><img src="MULTIMEDIA/facebook.png" class="Face-IMG" alt="Facebook logo"><p class="Face-txt">Facebook</p></a></li>
                <li><a href="https://twitter.com/Canrisk1" target="_blank"><img src="MULTIMEDIA/gorjeo.png" class="Twit-IMG" alt="Twitter"><p class="Twit-txt">Twitter</p></a></li>
            </ul>
            </div>
        </div>
    </footer>
</body>
</html>