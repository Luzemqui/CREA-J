<?php
session_start();
if (!isset($_SESSION["userSession"])) {
    $isEnglish   = strpos($_SERVER["REQUEST_URI"], "/INGLES/") !== false;
    $redirectUrl = $isEnglish ? "loginING.php" : "login.php";
    
    header("Location: " . $redirectUrl);
    exit; 
}

$sesion    = $_SESSION["userSession"] ?? null;
$isEnglish = strpos($_SERVER["REQUEST_URI"], "/INGLES/") !== false;
?><!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cuestionario - Canrisk</title>
    <link rel="stylesheet" href="../../CSS/Style-Info.css" />
    <link rel="stylesheet" href="../../CSS/quizz.css" />
    <link
      rel="icon"
      type="image/png"
      href="../../MULTIMEDIA/Canrisk LOGO.svg"
    />
  </head>
  <body>
    <!-- ===== LOGO Y BOTÓN DEL MENÚ LATERAL ===== -->
    <div class="navbar-brand">
      <button
        class="hamburger-sidebar-btn"
        id="sidebarBtn"
        aria-label="Abrir menú lateral"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
      <h1>Canrisk</h1>
      <img src="../../MULTIMEDIA/Canrisk LOGO.svg" alt="Canrisk" class="C-L" />
    </div>

    <!-- ===== MENÚ LATERAL (SIDEBAR) ===== -->
    <nav class="sidebar-menu" id="sidebarMenu">
      <div class="sidebar-decoracion">
        <span></span>
        <span></span>
        <span></span>
      </div>

      <ul class="sidebar-list">
        <li><a href="cancer-intro.php">Introducción al cáncer &rarr;</a></li>
        <li><a href="cancer.php">Tipos de Cáncer &rarr;</a></li>
        <li><a href="psycho-help.php">Apoyo psicológico &rarr;</a></li>
        <li><a href="help.php">Centro de ayuda &rarr;</a></li>
            <li><a href="recetas.php">Recetas saludables &rarr;</a></li>
        <li><a href="quizz.php">Cuestionario &rarr;</a></li>
        <li><a href="faq.php">Preguntas frecuentes &rarr;</a></li>
      </ul>
    </nav>

    <!-- ===== FONDO OSCURO AL ABRIR EL SIDEBAR ===== -->
    <div class="overlay-menu" id="menuOverlay"></div>

    <!-- ===== BARRA DE NAVEGACIÓN SUPERIOR ===== -->
    <nav class="navbar" id="mainNav">

      <ul class="Info-nav">
        <li class="box-II">
          <h4><a href="../ESPANOL/Principal.php">Inicio</a></h4>
        </li>
        <li class="box-II">
          <a href="../ESPANOL/aboutus.php"><h4>Sobre nosotros</h4></a>
        </li>
        <li class="box-II">
          <a href="../ESPANOL/Contacto.php"><h4>Contáctanos</h4></a>
        </li>
      </ul>

      <div class="right-group">
        <a
          id="langSwitch"
          class="lang-switch"
          href="<?php echo $isEnglish ? '../ESPANOL/Principal.php' : '../INGLES/PrincipalING.php'; ?>"
          aria-label="Cambiar idioma / Switch language"
          ><?php echo $isEnglish ? 'ES' : 'EN'; ?></a
        >

        <?php if ($sesion): ?>
          <div class="Photo user-session">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="48"
              height="48"
              fill="currentColor"
              class="bi bi-person-circle"
              viewBox="0 0 16 16"
            >
              <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
              <path
                fill-rule="evenodd"
                d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
              />
            </svg>
            <div class="user-info">
              <span class="session-label">
                <?php echo $isEnglish ? 'Signed in as' : 'Sesión iniciada como'; ?>
              </span>
              <a class="username-link" href="usuarios.php">
                <strong><?php echo htmlspecialchars($sesion['username'], ENT_QUOTES); ?></strong>
              </a>
              <a class="logout-link" href="../../PHP/logout.php">
                <?php echo $isEnglish ? 'Log out' : 'Cerrar sesión'; ?>
              </a>
            </div>
          </div>
        <?php else: ?>
          <div class="Photo">
            <a
              href="login.php"
              aria-label="Iniciar sesión / Login"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="48"
                height="48"
                fill="currentColor"
                class="bi bi-person-circle"
                viewBox="0 0 16 16"
              >
                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                <path
                  fill-rule="evenodd"
                  d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
                />
              </svg>
            </a>
          </div>
        <?php endif; ?>
      </div>
    </nav>

    <!-- ===== ENCABEZADO DE LA PÁGINA ===== -->
    <div class="Titulos">
      <h1>Cuestionario de Concientización</h1>
    </div>
    <br />
    <div class="fila-texto-img">
      <div class="content-text">
        <div class="Start">
          <p>
            ¿Qué tanto conocemos realmente sobre el cáncer? Este cuestionario
            busca evaluar el nivel de información y comprensión general que
            tiene la comunidad sobre la enfermedad, sus definiciones y los
            hábitos preventivos clave.
          </p>
          <br />
          <p>
            Tu participación nos ayuda a identificar áreas críticas donde se
            requiere mayor difusión de contenido educativo, entender la relación
            de las personas con los chequeos médicos y fortalecer la empatía
            colectiva.
          </p>
        </div>
      </div>

      <div class="IMG">
        <img
          src="../../MULTIMEDIA/cancer img.2.jpe"
          alt="Evaluación de conocimiento sobre el cáncer"
          class="IMG-TXT"
        />
      </div>
    </div>

    <div class="action-container">
      <a
        href="https://docs.google.com/forms/d/e/1FAIpQLSeA_wRqpODvoCKK3eUJ1uvN3IjVLjKseehsvB1lB7wfm2d04A/viewform?usp=publish-editor"
        target="_blank"
        class="btn-quizz"
      >
        Responder Cuestionario en Google Forms &rarr;
      </a>
    </div>

    <div class="info-grid">
      <div class="info-card">
        <h3>Concepto y Conocimiento Real</h3>
        <p>
          ¿Qué es el cáncer para ti? Analizamos la autopercepción que posees de
          la enfermedad, midiendo si te consideras poco, medianamente o bien
          informado frente a sus implicaciones.
        </p>
      </div>

      <div class="info-card">
        <h3>Prevención y Rutina Médica</h3>
        <p>
          La prevención salva vidas. Registramos la frecuencia con la que las
          personas se realizan chequeos médicos periódicos para evaluar el nivel
          de proactividad en el cuidado de la salud.
        </p>
      </div>

      <div class="info-card">
        <h3>Entorno Hospitalario e Interés</h3>
        <p>
          Evaluamos si los usuarios conocen los centros médicos especializados
          en tratamientos oncológicos y medimos su interés en continuar
          informándose para apoyar a sus seres queridos.
        </p>
      </div>

      <div class="info-card">
        <h3>Empatía y Acompañamiento</h3>
        <p>
          Buscamos entender la perspectiva humana y social del proceso,
          analizando la disposición individual de acompañar, visitar y
          comprender el día a día de un paciente en tratamiento.
        </p>
      </div>
    </div>

    <!-- ===== SECCIÓN DE DATOS DE CONCIENTIZACIÓN ===== -->
    <section class="awareness-banner">
      <div class="awareness-header">
        <h2>¿Por qué es vital informarnos?</h2>
        <p>
          La desinformación sigue siendo una de las principales barreras para
          una detección temprana y un acompañamiento efectivo.
        </p>
      </div>

      <div class="stats-grid">
        <div class="stat-box">
          <div class="stat-number">30% - 50%</div>
          <h4>Casos Prevenibles</h4>
          <p>
            Entre un tercio y la mitad de los casos de cáncer pueden prevenirse
            adoptando estilos de vida saludables y evitando factores de riesgo
            conocidos.
          </p>
        </div>

        <div class="stat-box">
          <div class="stat-number">Detección Precoz</div>
          <h4>Mayor Eficacia</h4>
          <p>
            Identificar la enfermedad en sus etapas iniciales aumenta
            considerablemente las probabilidades de éxito en el tratamiento y la
            recuperación.
          </p>
        </div>

        <div class="stat-box">
          <div class="stat-number">Red de Apoyo</div>
          <h4>Impacto Emocional</h4>
          <p>
            Contar con un entorno familiar y comunitario bien informado reduce
            significativamente el estrés y la ansiedad durante el proceso del
            paciente.
          </p>
        </div>
      </div>
    </section>

    <!-- ===== PIE DE PÁGINA ===== -->
    <footer>
      <div class="footer-container">
        <div class="footer-content">
          <div class="footer-col">
            <h2 class="Title">DERECHOS DE AUTOR</h2>
            <ul class="Advice">
              <li>&copy; Canrisk 2026</li>
              <li>&copy; Todos los derechos reservados al equipo de Canrisk</li>
              <li>Agradecimientos especiales al equipo de Canrisk</li>
              <li>que han hecho esta pagina algo posible.</li>
            </ul>
          </div>
          <div class="footer-col">
            <h2 class="Title_1">INFORMACIÓN IMPORTANTE</h2>
            <ul class="Advice_1">
              <li>
                Esta pagina NO reemplaza la ayuda de un profesional medico.
              </li>
              <li>
                En caso de tener algun tipo de emergencia o un sintoma puede
              </li>
              <li>
                apoyarse en los diferentes números de hospitales que nosotros
              </li>
              <li>proporcionamos, o llame directamente al 911.</li>
            </ul>
          </div>
        </div>
        <div class="footer-social">
          <h2 class="Title_2">Redes sociales de Canrisk!</h2>
          <ul class="Social">
            <li>
              <a href="https://www.instagram.com/canrisk/" target="_blank"
                ><img
                  src="../../MULTIMEDIA/instagram.png"
                  class="Inst-IMG"
                  alt="Instagram logo"
                />
                <p class="Inst-txt">Instagram</p></a
              >
            </li>
            <li>
              <a
                href="https://www.facebook.com/Canrisk-110882646091155"
                target="_blank"
                ><img
                  src="../../MULTIMEDIA/facebook.png"
                  class="Face-IMG"
                  alt="Facebook logo"
                />
                <p class="Face-txt">Facebook</p></a
              >
            </li>
            <li>
              <a href="https://twitter.com/Canrisk1" target="_blank"
                ><img
                  src="../../MULTIMEDIA/gorjeo.png"
                  class="Twit-IMG"
                  alt="Twitter"
                />
                <p class="Twit-txt">Twitter</p></a
              >
            </li>
          </ul>
        </div>
      </div>
    </footer>

    <script>
      const sidebarBtn = document.getElementById("sidebarBtn");
      const sidebarMenu = document.getElementById("sidebarMenu");
      const menuOverlay = document.getElementById("menuOverlay");

      const toggleSidebar = () => {
        const isOpen = sidebarMenu.classList.toggle("open");
        sidebarBtn.classList.toggle("open", isOpen);
        menuOverlay.classList.toggle("show", isOpen);
      };

      sidebarBtn.addEventListener("click", toggleSidebar);
      menuOverlay.addEventListener("click", toggleSidebar);
    </script>

    <script src="../../JS/site.js" defer></script>
  </body>
</html>
