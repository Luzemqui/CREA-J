<?php
session_start();
if (!isset($_SESSION["userSession"])) {
    $isEnglish   = strpos($_SERVER["REQUEST_URI"], "/INGLES/") !== false;
    $redirectUrl = $isEnglish ? "loginING.php" : "login.php";
    
    header("Location: " . $redirectUrl);
    exit; 
}

$sesion    = $_SESSION["userSession"] ?? null;
$isEnglish = strpos($_SERVER["REQUEST_URI"], "/INGLES/") !== false;
?><!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contacts - Canrisk</title>
    <link rel="stylesheet" href="../../CSS/contacto.css" />
    <link rel="stylesheet" href="../../CSS/Style-Info.css" />
    <link
      rel="icon"
      type="image/png"
      href="../../MULTIMEDIA/Canrisk LOGO.svg"
    />
  </head>
  <body>
    <div class="navbar-brand">
      <button
        class="hamburger-sidebar-btn"
        id="sidebarBtn"
        aria-label="Open sidebar menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
      <h1>Canrisk</h1>
      <img src="../../MULTIMEDIA/Canrisk LOGO.svg" alt="Canrisk" class="C-L" />
    </div>

    <nav class="sidebar-menu" id="sidebarMenu">
      <div class="sidebar-decoracion">
        <span></span>
        <span></span>
        <span></span>
      </div>

      <ul class="sidebar-list">
        <li>
          <a href="../INGLES/cancer-introING.php"
            >Introduction to Cancer &rarr;</a
          >
        </li>
        <li><a href="../INGLES/CancerING.php">Types of Cancer &rarr;</a></li>
        <li>
          <a href="../INGLES/psycho-helpING.php"
            >Psychological Support &rarr;</a
          >
        </li>
        <li><a href="../INGLES/helpING.php">Help Center &rarr;</a></li>
        <li><a href="../INGLES/recetasING.php">Healthy Recipes &rarr;</a></li>
        <li><a href="../INGLES/quizzING.php">Quiz &rarr;</a></li>
        <li>
          <a href="..//INGLES/faqING.php">Frequently Asked Questions &rarr;</a>
        </li>
      </ul>
    </nav>

    <div class="overlay-menu" id="menuOverlay"></div>

    <nav class="navbar" id="mainNav">

      <ul class="Info-nav">
        <li class="box-II">
          <h4><a href="../INGLES/PrincipalING.php">Home</a></h4>
        </li>
        <li class="box-II">
          <a href="../INGLES/aboutusENG.php"><h4>About Us</h4></a>
        </li>
        <li class="box-II">
          <a href="../INGLES/ContactoING.php"><h4>Contact Us</h4></a>
        </li>
      </ul>

      <div class="right-group">
        <a
          id="langSwitch"
          class="lang-switch"
          href="<?php echo $isEnglish ? '../ESPANOL/Principal.php' : '../INGLES/PrincipalING.php'; ?>"
          aria-label="Cambiar idioma / Switch language"
          ><?php echo $isEnglish ? 'ES' : 'EN'; ?></a
        >

        <?php if ($sesion): ?>
          <div class="Photo user-session">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="48"
              height="48"
              fill="currentColor"
              class="bi bi-person-circle"
              viewBox="0 0 16 16"
            >
              <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
              <path
                fill-rule="evenodd"
                d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
              />
            </svg>
            <div class="user-info">
              <span class="session-label">
                <?php echo $isEnglish ? 'Signed in as' : 'Sesión iniciada como'; ?>
              </span>
              <a class="username-link" href="usuariosING.php">
                <strong><?php echo htmlspecialchars($sesion['username'], ENT_QUOTES); ?></strong>
              </a>
              <a class="logout-link" href="../../PHP/logout.php">
                <?php echo $isEnglish ? 'Log out' : 'Cerrar sesión'; ?>
              </a>
            </div>
          </div>
        <?php else: ?>
          <div class="Photo">
            <a
              href="loginING.php"
              aria-label="Iniciar sesión / Login"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="48"
                height="48"
                fill="currentColor"
                class="bi bi-person-circle"
                viewBox="0 0 16 16"
              >
                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                <path
                  fill-rule="evenodd"
                  d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"
                />
              </svg>
            </a>
          </div>
        <?php endif; ?>
      </div>
    </nav>

    <header class="hero-section">
      <div class="hero-container">
        <div class="Titulos-DEG">
          <h1 class="hero-title">Contacts</h1>
        </div>
        <p class="hero-subtitle">Phone numbers for cancer treatment centers</p>
      </div>
    </header>

    <main class="contacto-main">
      <div class="contacto-intro-box">
        <p>
          Finding the right number during an emergency shouldn't be difficult.
          That is why we gathered in one place the contact information for the
          main public hospitals in El Salvador treating cancer, along with our
          own technical support. Use the search bar to filter by hospital name
          or department, or simply explore the full list below.
        </p>
      </div>

      <div class="contacto-stats">
        <div class="stat-pill">
          <strong>15</strong>
          <span>Hospital centers</span>
        </div>
        <div class="stat-pill">
          <strong>6</strong>
          <span>Departments covered</span>
        </div>
        <div class="stat-pill">
          <strong>24/7</strong>
          <span>Most with continuous service</span>
        </div>
      </div>

      <div class="contacto-buscador">
        <input
          type="text"
          id="buscadorHospital"
          placeholder="Search by hospital or department (e.g., Santa Ana)"
        />
        <p class="buscador-resultado" id="buscadorResultado"></p>
      </div>

      <div class="contacto-grid" id="gridHospitales">
        <div
          class="contacto-card"
          data-nombre="Hospital de Oncología ISSS"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS Oncology Hospital</h3>
          <a class="dato" href="tel:+50325915400">2591-5400</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=1"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional Rosales"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Rosales National Hospital</h3>
          <a class="dato" href="tel:+50322319200">2231-9200</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=2"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital de Niños Benjamín Bloom"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Benjamín Bloom Children's Hospital</h3>
          <a class="dato" href="tel:+50325944000">2594-4000</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=3"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional de la Mujer"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>National Women's Hospital</h3>
          <a class="dato" href="tel:+50325652100">2565-2100</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=4"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Instituto del Cáncer de El Salvador"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Cancer Institute of El Salvador</h3>
          <a class="dato" href="tel:+50322254354">2225-4354</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            Service Mon - Fri: 7:00 AM - 4:00 PM
          </p>
          <a
            href="Contacto-detalleING.php?id=5"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional San Juan de Dios de Santa Ana"
          data-depto="Santa Ana"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>"San Juan de Dios" National Hospital of Santa Ana</h3>
          <a class="dato" href="tel:+50324840300">2484-0300</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Santa Ana
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=6"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional San Juan de Dios de San Miguel"
          data-depto="San Miguel"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>"San Juan de Dios" National Hospital of San Miguel</h3>
          <a class="dato" href="tel:+50326842700">2684-2700</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Miguel
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=7"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Médico Quirúrgico ISSS"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS Medical Surgical Hospital</h3>
          <a class="dato" href="tel:+50325914100">2591-4100</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=8"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Regional ISSS Santa Ana"
          data-depto="Santa Ana"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS Regional Hospital of Santa Ana</h3>
          <a class="dato" href="tel:+50324891400">2489-1400</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Santa Ana
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=9"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Regional ISSS San Miguel"
          data-depto="San Miguel"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS Regional Hospital of San Miguel</h3>
          <a class="dato" href="tel:+50326651200">2665-1200</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Miguel
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=10"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional General Masferrer"
          data-depto="Usulután"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Masferrer General National Hospital</h3>
          <a class="dato" href="tel:+50326090100">2609-0100</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Usulután
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=11"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital General ISSS"
          data-depto="San Salvador"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS General Hospital</h3>
          <a class="dato" href="tel:+50325912100">2591-2100</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            San Salvador
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=12"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional San Rafael"
          data-depto="Santa Tecla"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>San Rafael National Hospital</h3>
          <a class="dato" href="tel:+50325239700">2523-9700</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Santa Tecla
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=13"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Policlínico Zacamil ISSS"
          data-depto="Mejicanos"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>ISSS Zacamil Polyclinic Hospital</h3>
          <a class="dato" href="tel:+50325916600">2591-6600</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Mejicanos
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=14"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>

        <div
          class="contacto-card"
          data-nombre="Hospital Nacional Santa Teresa"
          data-depto="Zacatecoluca"
        >
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Santa Teresa National Hospital</h3>
          <a class="dato" href="tel:+50323624300">2362-4300</a>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; margin-top: 4px"
          >
            Zacatecoluca
          </p>
          <p
            class="dato"
            style="font-weight: 400; font-size: 0.85rem; color: #a1a1a1"
          >
            24-hour service.
          </p>
          <a
            href="Contacto-detalleING.php?id=15"
            style="
              display: inline-block;
              margin-top: 15px;
              color: #b23d74;
              font-weight: 700;
              text-decoration: none;
            "
            >View details &rarr;</a
          >
        </div>
      </div>

      <div class="contacto-intro" style="margin-top: 40px">
        <h2 style="font-size: 1.5rem; letter-spacing: 1px">
          Canrisk Technical Support Contact
        </h2>
      </div>

      <div class="contacto-grid">
        <div class="contacto-card">
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 5c0-1 1-2 2-2h2l2 5-2 2c1 3 3 5 6 6l2-2 5 2v2c0 1-1 2-2 2C10 20 4 14 4 5z"
              />
            </svg>
          </div>
          <h3>Phone number</h3>
          <a class="dato" href="tel:+50389905890">8990-5890</a>
        </div>

        <div class="contacto-card">
          <div class="icono-card" aria-hidden="true">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path
                d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
              />
              <polyline points="22,6 12,13 2,6" />
            </svg>
          </div>
          <h3>Email address</h3>
          <a class="dato" href="mailto:soporte@canrisk.com"
            >soporte@canrisk.com</a
          >
        </div>
      </div>

      <div class="contacto-faq">
        <h2 class="contacto-faq-titulo">Quick questions</h2>

        <div class="faq-item">
          <button class="faq-pregunta" type="button">
            When should I call 911 instead of a hospital?
          </button>
          <div class="faq-respuesta">
            <p>
              Call 911 if there is a life-threatening emergency that requires
              immediate attention: breathing difficulty, severe uncontrollable
              bleeding, intense chest pain, or loss of consciousness. For
              appointments, test results, or questions regarding treatment,
              contact the hospital directly.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <button class="faq-pregunta" type="button">
            Who should I call if I don't know which hospital corresponds to me?
          </button>
          <div class="faq-respuesta">
            <p>
              You can contact the Cancer Institute of El Salvador or the nearest
              public hospital to your location; they can guide you and, if
              necessary, refer you to the appropriate specialized center.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <button class="faq-pregunta" type="button">
            Does Canrisk technical support handle medical inquiries?
          </button>
          <div class="faq-respuesta">
            <p>
              No. Our support team only handles technical issues related to the
              platform, such as login errors or issues with the questionnaire.
              For medical inquiries, always contact a hospital or health
              professional directly.
            </p>
          </div>
        </div>
      </div>
    </main>

    <footer>
      <div class="footer-container">
        <div class="footer-content">
          <div class="footer-col">
            <h2 class="Title">COPYRIGHT</h2>
            <ul class="Advice">
              <li>&copy; Canrisk 2026</li>
              <li>&copy; All rights reserved to the Canrisk team</li>
              <li>Special thanks to the Canrisk team</li>
              <li>who made this page possible.</li>
            </ul>
          </div>
          <div class="footer-col">
            <h2 class="Title_1">IMPORTANT INFORMATION</h2>
            <ul class="Advice_1">
              <li>This page DOES NOT replace professional medical help.</li>
              <li>In case of an emergency or symptoms, you can rely</li>
              <li>on the various hospital numbers we provide,</li>
              <li>or call 911 directly.</li>
            </ul>
          </div>
        </div>
        <div class="footer-social">
          <h2 class="Title_2">Canrisk social media!</h2>
          <ul class="Social">
            <li>
              <a href="https://www.instagram.com/canrisk/" target="_blank"
                ><img
                  src="../../MULTIMEDIA/instagram.png"
                  class="Inst-IMG"
                  alt="Instagram logo"
                />
                <p class="Inst-txt">Instagram</p></a
              >
            </li>
            <li>
              <a
                href="https://www.facebook.com/Canrisk-110882646091155"
                target="_blank"
                ><img
                  src="../../MULTIMEDIA/facebook.png"
                  class="Face-IMG"
                  alt="Facebook logo"
                />
                <p class="Face-txt">Facebook</p></a
              >
            </li>
            <li>
              <a href="https://twitter.com/Canrisk1" target="_blank"
                ><img
                  src="../../MULTIMEDIA/gorjeo.png"
                  class="Twit-IMG"
                  alt="Twitter"
                />
                <p class="Twit-txt">Twitter</p></a
              >
            </li>
          </ul>
        </div>
      </div>
    </footer>

    <script>
      const sidebarBtn = document.getElementById("sidebarBtn");
      const sidebarMenu = document.getElementById("sidebarMenu");
      const menuOverlay = document.getElementById("menuOverlay");

      const toggleSidebar = () => {
        const isOpen = sidebarMenu.classList.toggle("open");
        sidebarBtn.classList.toggle("open", isOpen);
        menuOverlay.classList.toggle("show", isOpen);
      };

      sidebarBtn.addEventListener("click", toggleSidebar);
      menuOverlay.addEventListener("click", toggleSidebar);

      // INTERACTIVE HOSPITAL SEARCH ENGINE
      const inputBuscador = document.getElementById("buscadorHospital");
      const resultadoTexto = document.getElementById("buscadorResultado");
      const tarjetas = document.querySelectorAll(
        "#gridHospitales .contacto-card",
      );

      inputBuscador.addEventListener("input", () => {
        const termino = inputBuscador.value.trim().toLowerCase();
        let visibles = 0;

        tarjetas.forEach((tarjeta) => {
          const nombre = (tarjeta.dataset.nombre || "").toLowerCase();
          const depto = (tarjeta.dataset.depto || "").toLowerCase();
          const coincide = nombre.includes(termino) || depto.includes(termino);

          tarjeta.classList.toggle("oculta", !coincide);
          if (coincide) visibles++;
        });

        if (termino === "") {
          resultadoTexto.textContent = "";
        } else if (visibles === 0) {
          resultadoTexto.textContent = "No hospitals found matching criteria.";
        } else {
          resultadoTexto.textContent = `${visibles} hospital(s) found.`;
        }
      });

      // QUICK QUESTIONS ACCORDION
      document.querySelectorAll(".faq-item").forEach((item) => {
        const pregunta = item.querySelector(".faq-pregunta");
        const respuesta = item.querySelector(".faq-respuesta");

        pregunta.addEventListener("click", () => {
          const estaAbierto = item.classList.contains("abierto");

          document.querySelectorAll(".faq-item.abierto").forEach((otro) => {
            otro.classList.remove("abierto");
            otro.querySelector(".faq-respuesta").style.maxHeight = null;
          });

          if (!estaAbierto) {
            item.classList.add("abierto");
            respuesta.style.maxHeight = respuesta.scrollHeight + "px";
          }
        });
      });
    </script>
    <script src="../../JS/site.js" defer></script>
  </body>
</html>
